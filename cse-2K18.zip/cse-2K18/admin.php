<?php

echo"admin page"; ?>
