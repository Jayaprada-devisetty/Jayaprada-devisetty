<?php echo"student page"; ?>
